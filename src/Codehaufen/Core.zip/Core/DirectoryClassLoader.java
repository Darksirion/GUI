package Prototyp.Core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DirectoryClassLoader implements ClassLoader {
	// Attribute
	private String path;

	private static final String filePlaceholder = "==========";

	/**
	 * Konstruktor mit Pfadangabe
	 * 
	 * @param path Der Pfad der Datenbank
	 */
	public DirectoryClassLoader(String path) {
		this.path = path;
	}

	public FileNode getTree() {
		return new FileNode(new File(path));
	}

	/**
	 * Gibt einen Snippet anhand seines Primaerschluessels
	 * 
	 * @param primaryKey Der Primaerschluessel des Snippets
	 */
	public Snippet getSnippet(String primaryKey) {
		try {
			// Variablen werden geladen und initialisiert
			Snippet snip = new Snippet();
			File file = new File(primaryKey);
			String segment;
			FileReader reader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(reader);

			// Name
			snip.setName(bufferedReader.readLine());

			// Author
			snip.setAuthor(bufferedReader.readLine());

			// Datum
			snip.setDatum(bufferedReader.readLine());

			// Sprache
			snip.setSprache(bufferedReader.readLine());

			// Code-Segment
			segment = bufferedReader.readLine();
			//segment = readSegment(bufferedReader, filePlaceholder);
			snip.setCode(segment);

			// Notizen-Segment
			segment = bufferedReader.readLine();
			//segment = readSegment(bufferedReader, filePlaceholder);
			snip.setNotizen(segment);

			// Quellen-Segment
			segment = bufferedReader.readLine();
			//segment = readSegment(bufferedReader, filePlaceholder);
			snip.setQuellen(segment);

			bufferedReader.close();
			return snip;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Speichert einen Snippet ab
	 * 
	 * @param snip Der Snippet der gespeichert werden soll
	 */
	public void saveSnippet(Snippet snip) {
		try {
			// Variablen werden geladen und initialisiert
			File file = new File(snip.getPrimaryKey());
			FileWriter writer = new FileWriter(file);

			// Name
			writer.append(snip.getName());
			writer.append("\n");

			// Author
			writer.append(snip.getAuthor());
			writer.append("\n");

			// Datum
			writer.append(snip.getDatum());
			writer.append("\n");

			// Sprache
			writer.append(snip.getSprache());
			writer.append("\n");

			// Code-Segment
			writer.append(snip.getCode());
			writer.append("\n");

			// Notizen-Segment
			writer.append(snip.getNotizen());
			writer.append("\n");

			// Quellen-Segment
			writer.append(snip.getQuellen());
			writer.append("\n");

			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Liest einen Block an Zeilen aus einer Datei und gibt ihn als String zurueck
	 * 
	 * @param bufferedReader Ein BufferedReader der mit der File verbunden ist die gelesen werden soll
	 * @param placeholder Ein Platzhalter der bestimmt dass das Segment zu Ende ist
	 * @return Ein String der das Segment enthaelt
	 * @throws IOException
	 */
	private String readSegment(BufferedReader bufferedReader, String placeholder) throws IOException {
		String segment = "";
		String line = bufferedReader.readLine();

		while (!line.matches(placeholder)) {
			segment += line;
			line = bufferedReader.readLine();
		}

		return segment;
	}

}
