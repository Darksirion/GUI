package Prototyp.Core;

/**
 * Created by Darksirion on 09.09.15.
 */
public class Core {

    public void search(){

    }

    public void addSnippet(String name, String code, String notizen,String quellen, String author){
        loader.saveSnippet(new Snippet(name, code, notizen, quellen, author ));
        // Name aus textFieldName
        // Code aus textAreaCode
        // Notizen aus textAreaNote
        // Quelle Teilelement aus textAreaLegend (Object 1)
        // Author Teilement aus textAreaLegend (Object 2)
        // Lang Übergabe über Proxy von der GUI vom MenuButtonLang
        // Datum von Systemtime (wird Object 3 in textAreaLegend beim anzeigen)



    }

    public void deleteSnippet(Object Snippet){

        //identifizierung über PrimärKey, Übergabe vom PrimärKey über select im Tree

    }

    public void editSnippet (Object Snippet){

    // rechtsKlick zum initialisieren

        return Object newSnippet;
    }


    public void help(){
        //get help;
    }

    public void settings (){

        //new Lang
        //HotKey Change

    }

    public void addDirectory(){

        // Pop-Up in FXML dafür erstellen mit textFieldAddDirectory
    }

    public void renameDirectory(){

        //Verwendung Pop-Up von AddDirectory mit set vorhandenem Directory ) rechtsKlick
    }

    public Core() {
        DirectoryClassLoader loader = new DirectoryClassLoader();
        //shadow proxy
        //directory classloader


    }
}
