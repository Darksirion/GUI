package Prototyp.Core;

import java.io.File;

public interface ClassLoader {

	/**
	 * Gibt die gewaehlte Datenbank in Baumstruktur zurueck
	 * 
	 * @return Eine FileNode aus der die Datenbank-Struktur herausgelesen werden kann
	 */
	public FileNode getTree();

	/**
	 * Gibt einen Snippet aus der Datenbank anhand seines Primaer-Schluessels zureuck
	 * 
	 * @return Die gewuenschte File aus der Datenbank
	 */
	public Snippet getSnippet(String primaryKey);

	/**
	 * Speichert einen Snippet in der Datenbank
	 * 
	 * @param file Die Datei die in der Datenbank gespeichert werden soll
	 */
	public void saveSnippet(Snippet snippet);
}
